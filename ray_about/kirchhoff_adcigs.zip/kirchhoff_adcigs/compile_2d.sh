#mpif90  -f90=ifort 2D_Kirchhoff_PSDM_OUTPUT_ANGLE_GATHER_2013_0725_v2_diff_vreduce.f -lfftw3f -o k_psdm  -lm  -i-static -check bounds -traceback 
#mpif90  -f90=ifort 2D_Kirchhoff_PSDM_OUTPUT_ANGLE_GATHER_2013_0725_v2_diff_zwy0910.f -lfftw3f -o k_psdm  -lm  
#mpif90  -f90=ifort 2D_Kirchhoff_PSDM_OUTPUT_ANGLE_GATHER_2013_0725_v2_diff_zwy1017.f -lfftw3f -o k_psdm  -lm  
#mpif90  -f90=ifort 2D_Kirchhoff_PSDM_OUTPUT_ANGLE_GATHER_2013_0725_v2_diff_vreduce.f -lfftw3f -o k_psdm  -lm  
#mpif90  -f90=ifort 2D_Kirchhoff_PSDM_OUTPUT_ANGLE_GATHER_2013_0725_v2_diff_zwy_multishot2.f -lfftw3f   -o k_psdm2  -lm  -g
#mpif90  -f90=ifort 2D_Kirchhoff_PSDM_OUTPUT_ANGLE_GATHER_2013_0725_v2_diff_yuanshi.f -lfftw3f -o k_psdm  -lm  
mpif90  -f90=ifort 2D_Kirchhoff_PSDM_OUTPUT_ANGLE_GATHER_2013_0725_v2_diff_dip.f -lfftw3f -o k_psdm  -lm  
