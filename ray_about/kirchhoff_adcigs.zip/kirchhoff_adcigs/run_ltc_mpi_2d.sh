#time mpirun  -np 30 -machinefile nodefile k_psdm ./PSDM_WAXIAN.PAR </dev/null>log 2>err&
time mpirun  -np 20 -machinefile nodefile k_psdm ./input/PSDM_vshape.PAR </dev/null>log 2>err&
